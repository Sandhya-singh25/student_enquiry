package in.sandhyait.service;

import in.sandhyait.binding.DashboardResponse;
import in.sandhyait.entity.Counsellor;

public interface CounsellorService {
public String saveCounsellor(Counsellor c);
public Counsellor loginCheck(String email,String pwd);
public boolean recoverPwd(String emai);
public DashboardResponse getDashboardInfo(Integer cid);

}
