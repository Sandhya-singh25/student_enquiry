package in.sandhyait.service;

import java.util.List;

import in.sandhyait.binding.SearchCriteria;
import in.sandhyait.entity.StudentEnq;

public interface EnquiryService {
	public boolean addEnq(StudentEnq se);
	public List<StudentEnq> getEnquiries(Integer cid,SearchCriteria s);

}
